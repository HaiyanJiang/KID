# -*- coding: utf-8 -*-
"""
Created on Tue Aug  4 20:27:41 2020

@name: Haiyan Jiang
@author: jianghaiyan01
@mail: jianghaiyan01@baidu.com

"""


# from distutils.core import setup
from setuptools import setup


with open("README.md", "r") as fh:
    long_description = fh.read()

setup(
    name="ridger",
    version="0.0.1",
    author="Haiyan Jiang",
    author_email="jianghaiyan01@baidu.com",
    description="A ridger package to get the whole path",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent"
        ],
    # packages=setuptools.find_packages(),
    py_modules=[
        "ridger.gendata",
        "ridger.solver",
        "ridger.criter"
        ],
    install_requires=["numpy", "sklearn", "matplotlib"]
    )