# -*- coding: utf-8 -*-
"""
Created on Wed Aug  5 14:13:53 2020

@name: Haiyan Jiang
@author: jianghaiyan01
@mail: jianghaiyan01@baidu.com

"""


This is a package for finding the solution path of L2 regularization.

The name of the package is "ridger", because it deals with the ridge regularizer. You can pip install and use the package as numpy or pandas.

