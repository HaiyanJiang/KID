# -*- coding: utf-8 -*-
"""
Created on Tue Aug  4 19:43:02 2020

@name: Haiyan Jiang
@author: jianghaiyan01
@mail: jianghaiyan01@baidu.com

"""

import numpy as np
from sklearn import linear_model

# %matplotlib inline
# %matplotlib qt5


class PathSolver():
    """ 
    The path solver gives the whole path of the OLS with ridge regularization, 
    whether through implicit or explicit way. 
    The ridge path can be obtained from the closed-form, which is of course the
    explicit way, while the OLS_GD and OLS_batchSGD gives the path though GD or
    SGD with the implicit regularization.
    """
    
    def __init__(self, eta=1e-3, iter_max=1e3):
        """ 
        Parameters
        ----------
        eta: 
            the learning rate, default 1e-3.
        iter_max: 
            the maximum number of iterations, default 1e3.
        """
        self.eta = eta
        self.iter_max = iter_max
    
    def OLS_GD(self, X, y):
        """
        Gradient Descent for OLS (Ordinal Least Squares).
        
        Parameters
        ----------
        X, y: 
            the regression data in OLS, X is n by p, y is n by 1.
        
        Examples
        --------
        >>> from ridger.gendata import gen_data
        >>> n, p = 500, 10
        >>> sigma0 = 2
        >>> mean0 = np.zeros(p)
        >>> cov0 = sigma0 * np.diag(np.ones(p))  # diagonal covariance
        >>> X, y, beta_true = gen_data(n, p, mean0, cov0, residualform='normal')
        >>> sol = PathSolver(eta=1e-3, iter_max=1e3)
        >>> sol.OLS_GD(X, y)
        >>> coefs_gd = sol.coefs
        >>> errors_gd = estimation_error(coefs_gd, beta_true)
        >>> coefs_plot(coefs_gd, x_label="Iterations", title_="Gradient descent")
        >>> coefs_plot(errors_gd, x_label="Iterations", y_label="Norm errors", title_="Gradient descent")
        """
        n, p = X.shape
        beta = np.zeros(p)
        coefs = []  # the number of coefs is the number of iterations.
        i = 0
        while i < self.iter_max:
            i += 1
            coefs.append(beta)
            beta = beta + self.eta / n * np.dot(X.T, y-np.dot(X, beta))
        self.coefs = coefs
        return coefs
    
    def OLS_batchSGD(self, X, y, m=100):
        """
        mini-batch Stochastic Gradient Descent (SGD) for OLS (Ordinal Least Squares).
        
        Parameters
        ----------
        X, y: 
            the regression data in OLS, X is n by p, y is n by 1.
        m: 
            the mini-batch size, default 100, or min([int(m), int(n/2)]).
        """
        n, p = X.shape
        beta = np.zeros(p)  # with zeros initialized
        # For the minibatch SGD, set the mini-batch size and do sampling
        m0 = min([int(m), int(n/2)])
        coefs = []  # the number of coefs is the number of iterations.
        i = 0
        while i < self.iter_max:
            i += 1
            # append to the coefficients list
            coefs.append(beta)
            idx1 = np.random.choice(range(n), m0)  # ## random sampling
            X1, y1 = X[idx1, ], y[idx1]
            beta = beta + self.eta / m0 * np.dot(X1.T, y1-np.dot(X1, beta))
        self.coefs = coefs
        return coefs

    def ridge_path_sklearn(self, X, y, alphas):
        """ ridge path with the default sklearn """
        clf = linear_model.Ridge(fit_intercept=False)
        coefs = []
        for a in alphas:
            clf.set_params(alpha=a)
            clf.fit(X, y)
            coefs.append(clf.coef_)
        self.coefs = coefs
        return coefs
    
    def ridge_path_inverse(self, X, y, alphas):
        """ ridge path with the closed-form, which uses matrix inverse """
        # The closed form
        p = X.shape[1]
        coefs = []
        for a in alphas:
            tmp = np.linalg.inv(np.dot(X.T, X) + a * np.diag(np.ones(p)))
            b = np.dot(tmp, np.dot(X.T, y))
            coefs.append(b)
        self.coefs = coefs
        return coefs

