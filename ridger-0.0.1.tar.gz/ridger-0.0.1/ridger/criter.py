# -*- coding: utf-8 -*-
"""
Created on Wed Aug  5 10:08:35 2020

@name: Haiyan Jiang
@author: jianghaiyan01
@mail: jianghaiyan01@baidu.com

"""

import matplotlib.pyplot as plt
from sklearn.metrics import mean_squared_error


def estimation_error(coefs, beta_true):
    """ The estimation error based on the ture beta.
    
    Parameters
    ----------
    coefs:
        The list of coefficients.
    beta_true:
        The true beta.
    """
    errors = []
    for beta in coefs:
        errors.append(mean_squared_error(beta, beta_true))
    return errors


def coefs_plot(
        coefs, alphas=None, reverse_x=False, log_x=False,
        x_label=None, y_label=None, title=None):
    """ Plot the coefficients vs the alphas. 
    If there is no given alphas, then plot the coefficient itself.
    
    Parameters
    ----------
    coefs: 
        The list of coefficients, as the y-axis
    alphas:
        The x-axis. Default, None.
    """
    plt.figure()
    ax = plt.gca()
    # # alphas = lambda
    if alphas is None:
        ax.plot(coefs)
    else:
        ax.plot(alphas, coefs)
    if log_x:
        ax.set_xscale('log')
    if reverse_x:
        ax.set_xlim(ax.get_xlim()[::-1])
    if x_label is None:
        plt.xlabel('Parameters')
    else:
        plt.xlabel(x_label)
    if y_label is None:
        plt.ylabel('Coefficients')
    else:
        plt.ylabel(y_label)
    if title is None:
        plt.title('Ridge coefficients as a function of the regularization')
    else:
        plt.title(title)
    plt.axis('tight')
    plt.show()


