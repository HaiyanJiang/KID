# -*- coding: utf-8 -*-
"""
Created on Tue Aug  4 20:12:56 2020

@name: Haiyan Jiang
@author: jianghaiyan01
@mail: jianghaiyan01@baidu.com

"""

import numpy as np


def gen_IND_residual(n, residualform="normal"):
    """
    # normal, t, chisq, uniform, default is normal dist.
    # generate the independent data based on different residual form.
    # We need to normalize the variance s.t. variance = 1.
    # So we can only focus on different shapes.
    """
    if (residualform == "normal"):
        eps = np.random.normal(0, 1, n)
        # What is the difference between N(0, sigma^2 I) and N(0, 1)
        # eps <- matrix(rnorm(n * p, 0, 1), n, p)  # spurious correlation
    elif (residualform == "t"):
        # t_{v}, the df = v, then the mean is 0, and the variance is v / (v-2)
        tmp = np.random.standard_t(df=5, size=n)
        eps = tmp / np.sqrt(5/3)
    elif (residualform == "chisq"):  # chisquare
        # chisq_{v}, the df = v, then the mean is v, and the variance is 2*v
        tmp = np.random.chisquare(df=3, size=n)
        eps = (tmp - 3) / np.sqrt(6)
    elif (residualform == "uniform"):
        # Uniform(a, b), mean (a+b)/2, variance (b-a)^2/12
        a, b = -np.sqrt(3), np.sqrt(3)
        s = np.sqrt((b - a) ** 2 / 12)    # Here s = 1
        tmp = np.random.uniform(a, b, size=n)
        eps = tmp / s
    else:
        eps = np.random.normal(0, 1, n)
    return eps


def gen_data(n, p, mean0, cov0, residualform='normal'):
    # Y = X * beta + Eps
    X = np.random.multivariate_normal(mean0, cov0, n)
    beta_true = list(map(lambda x: round(x, 3), np.random.uniform(-1, 1, p)))
    # print(beta_true)
    eps = gen_IND_residual(n, residualform=residualform)
    y = np.dot(X, beta_true) + eps
    return X, y, beta_true

